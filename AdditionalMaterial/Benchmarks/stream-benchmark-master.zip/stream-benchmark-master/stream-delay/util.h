#ifndef __UTIL_H
#define __UTIL_H

#include <stdlib.h>

int memcpy_read(void *dest, void *src, size_t len);


#endif
